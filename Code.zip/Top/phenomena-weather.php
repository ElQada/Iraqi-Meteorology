<div id="Top">
    <input type="hidden" value="<?=_SESSION_('Account')?>" name="Account" id="Account">
</div>