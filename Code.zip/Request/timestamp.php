<?php
//"Asia/Baghdad"
//date_default_timezone_set ('Asia/Baghdad');
//date_timezone_set(new DateTime(),timezone_open ('Asia/Baghdad'));
//date_default_timezone_set ( 'Europe/London' );
//date_timezone_set(new DateTime(),timezone_open ('Europe/London'));
 echo date( 'H:i:s' );
 // timestamp