function timech(File)
{

}
var Mean = {
    "602": {
        "12": "3.07",
        "01": "1.64",
        "02": "2.85",
        "06": "38.7",
        "07": "42.54",
        "08": "42.09"
    },
    "603": {
        "12": "6",
        "01": "4.16",
        "02": "5.27",
        "06": "39.31",
        "07": "42.75",
        "08": "42.44"
    },
    "608": {
        "12": "4.36",
        "01": "3.12",
        "02": "4.2",
        "06": "40.26",
        "07": "43.73",
        "08": "43.6"
    },
    "621": {
        "12": "6.91",
        "01": "5.26",
        "02": "6.68",
        "06": "40.88",
        "07": "44.01",
        "08": "43.84"
    },
    "627": {
        "12": "4.21",
        "01": "3.31",
        "02": "5.12",
        "06": "39.06",
        "07": "41.81",
        "08": "41.58"
    },
    "629": {
        "12": "4.24",
        "01": "2.83",
        "02": "4.36",
        "06": "39.68",
        "07": "42.52",
        "08": "42.21"
    },
    "631": {
        "12": "5.92",
        "01": "4.72",
        "02": "6.41",
        "06": "41.37",
        "07": "44.39",
        "08": "44.2"
    },
    "632": {
        "12": "6.57",
        "01": "5.2",
        "02": "6.68",
        "06": "40.85",
        "07": "43.88",
        "08": "43.67"
    },
    "633": {
        "12": "6.3",
        "01": "4.96",
        "02": "6.66",
        "06": "41.54",
        "07": "44.38",
        "08": "44.4"
    },
    "634": {
        "12": "5.26",
        "01": "3.46",
        "02": "5.22",
        "06": "40.39",
        "07": "43.46",
        "08": "43.15"
    },
    "637": {
        "12": "6.81",
        "01": "5.37",
        "02": "6.7",
        "06": "43.14",
        "07": "45.73",
        "08": "45.95"
    },
    "638": {
        "12": "5.34",
        "01": "4.14",
        "02": "5.92",
        "06": "41.31",
        "07": "43.97",
        "08": "43.88"
    },
    "642": {
        "12": "4.5",
        "01": "3.13",
        "02": "5.11",
        "06": "37.24",
        "07": "39.76",
        "08": "40"
    },
    "645": {
        "12": "6.8",
        "01": "5.43",
        "02": "6.54",
        "06": "40.91",
        "07": "43.63",
        "08": "43.67"
    },
    "646": {
        "12": "5.25",
        "01": "4.67",
        "02": "5.44",
        "06": "41.48",
        "07": "42.71",
        "08": "44.15"
    },
    "650": {
        "12": "6.24",
        "01": "4.86",
        "02": "6.71",
        "06": "42.49",
        "07": "44.96",
        "08": "44.84"
    },
    "655": {
        "12": "6.46",
        "01": "4.92",
        "02": "6.44",
        "06": "41.66",
        "07": "44.4",
        "08": "43.98"
    },
    "656": {
        "12": "7.67",
        "01": "6.32",
        "02": "8.47",
        "06": "42.65",
        "07": "45.28",
        "08": "45.15"
    },
    "657": {
        "12": "7.06",
        "01": "5.63",
        "02": "7.39",
        "06": "42.2",
        "07": "45.2",
        "08": "44.61"
    },
    "658": {
        "12": "5.62",
        "01": "4.28",
        "02": "5.71",
        "06": "41.2",
        "07": "44.61",
        "08": "44.36"
    },
    "660": {
        "12": "7.67",
        "01": "5.42",
        "02": "8.21",
        "06": "43.29",
        "07": "44.88",
        "08": "45.21"
    },
    "662": {
        "12": "7.28",
        "01": "5.39",
        "02": "6.62",
        "06": "42.8",
        "07": "44.8",
        "08": "44.45"
    },
    "664": {
        "12": "6.2",
        "01": "6.7",
        "02": "7.12",
        "06": "43.2",
        "07": "45.6",
        "08": "45.2"
    },
    "665": {
        "12": "7.3",
        "01": "5.69",
        "02": "6.8",
        "06": "44.2",
        "07": "45.4",
        "08": "45.8"
    },
    "666": {
        "12": "7.88",
        "01": "6.34",
        "02": "7.32",
        "06": "43.23",
        "07": "44.8",
        "08": "45.65"
    },
    "670": {
        "12": "6.74",
        "01": "5.2",
        "02": "5.84",
        "06": "42.7",
        "07": "44.9",
        "08": "44.5"
    },
    "672": {
        "12": "7.12",
        "01": "6.43",
        "02": "6.9",
        "06": "43.21",
        "07": "44.87",
        "08": "45.6"
    },
    "674": {
        "12": "6.7",
        "01": "5.89",
        "02": "6.21",
        "06": "43.21",
        "07": "45.1",
        "08": "45.02"
    },
    "675": {
        "12": "6.8",
        "01": "5.88",
        "02": "6.34",
        "06": "42.4",
        "07": "44.8",
        "08": "45.4"
    },
    "676": {
        "12": "6.5",
        "01": "5.32",
        "02": "6.88",
        "06": "43.1",
        "07": "44.5",
        "08": "45.21"
    },
    "680": {
        "12": "6.54",
        "01": "5.76",
        "02": "6.2",
        "06": "43.2",
        "07": "44.97",
        "08": "44.8"
    },
    "689": {
        "12": "6.12",
        "01": "6.1",
        "02": "6.56",
        "06": "42.3",
        "07": "44.4",
        "08": "43.98"
    },
    "690": {
        "12": "6.78",
        "01": "5.6",
        "02": "6.98",
        "06": "43.8",
        "07": "44.4",
        "08": "45.3"
    },
    "691": {
        "12": "7.56",
        "01": "5.89",
        "02": "6.44",
        "06": "44.2",
        "07": "45.1",
        "08": "44.8"
    }
};
var $Heat = [], $Cold = [], SetCold = [], SetHeat = [], ColdDay = {}, HeatDay = {};
if ($AllStations.length)
{
    $AllStations.forEach(($Fetch)=>{
        $Fetch.Records.forEach(($Record)=>{
            if (Mean.hasOwnProperty($Fetch.Code))
            {
                if (Mean[$Fetch.Code].hasOwnProperty($Fetch.Month))
                {
                    let $TNTNTN = parseFloat($Record.TNTNTN),$Mean = Mean[$Fetch.Code][$Fetch.Month];
                    if (['-','1',1].includes($Record.SN3))
                    {
                        $TNTNTN *= -1;
                    }
                    let $Disunite = parseFloat(Math.abs(parseFloat($Mean) - parseFloat($TNTNTN))).toFixed(2);
                    if ($Disunite>=3)
                    {
                        let Row = {Station:$Fetch.Station,Code:$Fetch.Code,Year:$Fetch.Year,Month:$Fetch.Month,Day:$Record.date.split('-')[2],TNTNTN:$TNTNTN,Mean:$Mean,Disunite:$Disunite};
                        if (["01","02","12"].includes($Fetch.Month))
                        {
                            $Cold.push(Row);
                        }
                        else
                        {
                            $Heat.push(Row);
                        }
                    }
                }
                else
                {
                    console.info($Fetch.Month);
                }
            }
            else
            {
                console.info($Fetch.Code);
                console.info($Fetch.Station);
            }
        });
        if (["01","02","12"].includes($Fetch.Month))
        {
            $Cold.push({});
        }
        else
        {
            $Cold.push({});
        }
    });

    let Count = 0, Days = [];
    for (let I = 0; I<Object.keys($Cold).length-1; I++)
    {
        if ((parseInt($Cold[I+1].Day)-parseInt($Cold[I].Day)) === 1)
        {
            Count++;
            Days.push($Cold[I]);
        }
        else
        {
            if (Count > 1)
            {
                Days.push($Cold[I]);
                Days.forEach((Day)=>{ SetCold.push(Day); });
                SetCold.push({Station:"Main @ "+Days[0].Station,Code:Days[0].Code,Year:Days[0].Year,Month:Days[0].Month,Day:Days.length,TNTNTN:'',Mean:Days[0].Mean,Disunite:''});
            }
            Count = 0;
            Days = [];
        }
    }
    Count = 0;
    Days = [];
    for (let I = 0; I<Object.keys($Heat).length-1; I++)
    {
        if ((parseInt($Heat[I+1].Day)-parseInt($Heat[I].Day)) === 1)
        {
            Count++;
            Days.push($Heat[I]);
        }
        else
        {
            if (Count > 1)
            {
                Days.push($Heat[I]);
                Days.forEach((Day)=>{ SetHeat.push(Day); });
                SetHeat.push({Station:"Main @ "+Days[0].Station,Code:Days[0].Code,Year:Days[0].Year,Month:Days[0].Month,Day:Days.length,TNTNTN:'',Mean:Days[0].Mean,Disunite:''});
            }
            Count = 0;
            Days = [];
        }
    }
}
ElqadaDataTable.$Page.Size = 'A3';
ElqadaDataTable.$Page.Orientation = 'portrait';
if (SetCold.length)
{
    ElqadaDataTable.ID('Stations-Month-SetCold')
        .Name('مــوجــات الـبــرودة').Element('Month-SetCold')
        .Rename({"TNTNTN":"L-Temperature",'Count':'Main-N','Disunite':'الـفـرق'}).Data(SetCold)
        .Keys(['Station','Code','Year','Month','Day','TNTNTN','Mean','Disunite'])
        .Length({"50":50,"100":100})
        .Set(['Select','Reselect','PDF','Excel','Print']);
}
if (SetHeat.length)
{
    ElqadaDataTable.ID('Stations-Month-SetHeat')
        .Name('مــوجــات الـــحــرارة').Element('Month-SetHeat')
        .Rename({"TNTNTN":"H-Temperature",'Count':'Main-N','Disunite':'الـفـرق'}).Data(SetHeat)
        .Keys(['Station','Code','Year','Month','Day','TNTNTN','Mean','Disunite'])
        .Length({"50":50,"100":100})
        .Set(['Select','Reselect','PDF','Excel','Print']);
}